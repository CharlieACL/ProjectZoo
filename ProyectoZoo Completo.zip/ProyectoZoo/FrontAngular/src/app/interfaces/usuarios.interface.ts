export interface UsuariosCollection{
    _id:string;
    nombre: string;
    correo: string;
    contrasenna: string;
    idRol: string;
    __v: number;
    token: string;
    error: string;
}