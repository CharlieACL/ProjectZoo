export interface EventosCollection{
    _id:string;
    descripcion: string;
    dia: string;
    hora: string;
    duracion: string;
    estado: boolean;
    __v: number;
}