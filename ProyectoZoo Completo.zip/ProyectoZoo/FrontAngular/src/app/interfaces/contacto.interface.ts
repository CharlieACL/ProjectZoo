export interface ContactoCollection {
    _id:string;
    correo: string,
    telefono: string,
    mensaje: string
    __v: number;
    mensajeRespuesta: string;
}