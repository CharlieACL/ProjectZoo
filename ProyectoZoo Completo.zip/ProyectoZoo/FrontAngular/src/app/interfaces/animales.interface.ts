export interface AnimalesCollection {
    _id:string;
    especie: string;
    nombre: string;
    sexo: string;
    peso: string;
    altura: string;
    idZona: string;
    edad: number;
    activo: boolean;
    __v: number;
}
