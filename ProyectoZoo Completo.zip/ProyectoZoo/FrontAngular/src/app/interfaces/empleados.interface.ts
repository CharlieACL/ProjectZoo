export interface EmpleadosCollection {
    _id:string;
    nombre: string,
    apellido: string,
    identificacion: number,
    telefono: string,
    idServicio: string,
    __v: number;
}